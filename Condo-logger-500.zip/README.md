# Condo-logger

To start runn following command:
```
npm i
```

Place a DISCORD ACCOUNT token in fetch.js <br/>
Place a DISCORD BOT token in server.js

Project by [Steppa Condos](https://discord.gg/TwEyBaP2UU)
